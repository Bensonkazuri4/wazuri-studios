import React, { useState } from 'react'
import { ArrowUpRight, Menu, X, Play, Instagram, Facebook, Youtube, MonitorPlay, RadioTower, Megaphone, Share2, Clapperboard, CheckCircle2, Mail, Phone, MapPin, Settings, LayoutDashboard, Image, MessageSquare, LogOut } from 'lucide-react'

const services = [
  { icon: Megaphone, number: '01', title: 'Advertising & Brand Promotion', text: 'Build visibility and connect your brand with the people who matter through thoughtful campaigns and creative promotions.' },
  { icon: Share2, number: '02', title: 'Social Media Management', text: 'Create a consistent digital presence with content planning, page management and audience engagement.' },
  { icon: RadioTower, number: '03', title: 'TV Setup & Streaming', text: 'Professional television setup and streaming solutions designed for reliable, quality broadcasting.' },
  { icon: MonitorPlay, number: '04', title: 'TV Software Installation', text: 'Installation, configuration and support for television playout and broadcast software.' }
]

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [adminOpen, setAdminOpen] = useState(false)
  const [sent, setSent] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', service: 'Advertising & Brand Promotion', message: '' })
  const [content, setContent] = useState({ headline: 'Ideas that move people.', intro: 'Creative media and broadcast solutions that help your brand stand out.' })

  const closeMenu = () => setMenuOpen(false)
  const submit = (e) => { e.preventDefault(); setSent(true) }

  return (
    <div className="site-shell">
      <header className="header">
        <a className="brand" href="#home" onClick={closeMenu}>
          <span className="brand-mark">W</span>
          <span><b>WAZURI</b><small>STUDIOS</small></span>
        </a>
        <nav className={menuOpen ? 'nav nav-open' : 'nav'}>
          <a href="#home" onClick={closeMenu}>Home</a><a href="#about" onClick={closeMenu}>About</a><a href="#services" onClick={closeMenu}>Services</a><a href="#work" onClick={closeMenu}>Our approach</a><a href="#contact" className="nav-cta" onClick={closeMenu}>Let's talk <ArrowUpRight size={15}/></a>
        </nav>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">{menuOpen ? <X/> : <Menu/>}</button>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-glow"></div>
          <div className="hero-copy">
            <div className="eyebrow"><span></span> CREATIVE MEDIA · BROADCAST · DIGITAL</div>
            <h1>{content.headline.split(' ').slice(0, -2).join(' ')} <em>{content.headline.split(' ').slice(-2).join(' ')}</em></h1>
            <p>{content.intro}</p>
            <div className="hero-actions"><a className="button button-light" href="#contact">Start a project <ArrowUpRight size={17}/></a><a className="text-link" href="#services">Explore services <span>↗</span></a></div>
            <div className="hero-note"><span className="note-line"></span><span>LET'S FIX YOU</span><span className="note-muted">— Your ideas, brought to life.</span></div>
          </div>
          <div className="hero-art" aria-label="Abstract studio visual">
            <div className="art-ring ring-one"></div><div className="art-ring ring-two"></div>
            <div className="art-panel"><div className="panel-top"><span>WZ / STUDIO</span><span>01 — 04</span></div><div className="panel-center"><Clapperboard size={58} strokeWidth={1}/><span>MAKE<br/>IT MATTER.</span></div><div className="panel-bottom"><span>CREATIVE DIRECTION</span><span>EST. 2024</span></div></div>
            <div className="floating-tag">CREATIVITY IN MOTION <ArrowUpRight size={14}/></div>
          </div>
          <div className="hero-bottom"><span>01 / INTRODUCTION</span><span>SCROLL TO DISCOVER ↓</span><span>KENYA · AVAILABLE EVERYWHERE</span></div>
        </section>

        <section className="intro-section section-pad" id="about">
          <div className="section-label">WHO WE ARE <span>01</span></div>
          <div className="intro-grid"><h2>We turn good ideas into <em>great experiences.</em></h2><div className="intro-text"><p>Wazuri Studios is a creative media and broadcast solutions studio. We help businesses, organisations and creators communicate clearly, reach the right audience and deliver with confidence.</p><a className="under-link" href="#contact">Tell us what you're building <ArrowUpRight size={16}/></a></div></div>
        </section>

        <section className="services-section section-pad" id="services">
          <div className="section-label">WHAT WE DO <span>02</span></div>
          <div className="section-heading"><h2>Services made to<br/><em>make a difference.</em></h2><p>Focused expertise. Thoughtful execution.<br/>Solutions that work in the real world.</p></div>
          <div className="service-list">{services.map(({icon: Icon, number, title, text}) => <article className="service-row" key={number}><span className="service-number">{number}</span><div className="service-icon"><Icon size={23} strokeWidth={1.5}/></div><div className="service-copy"><h3>{title}</h3><p>{text}</p></div><ArrowUpRight className="service-arrow" size={21}/></article>)}</div>
        </section>

        <section className="feature-section" id="work">
          <div className="feature-image"><div className="feature-image-inner"><div className="viewfinder"><span>REC</span><i></i><b>WZ</b><small>FRAME THE FUTURE</small></div></div></div>
          <div className="feature-copy"><div className="section-label">OUR APPROACH <span>03</span></div><h2>Good work starts with <em>listening.</em></h2><p>Every project begins with understanding your goals. We bring together creativity, practical experience and the right technology to deliver work that feels considered and performs.</p><div className="approach-points"><div><CheckCircle2 size={17}/> Clear communication</div><div><CheckCircle2 size={17}/> Reliable delivery</div><div><CheckCircle2 size={17}/> Solutions built around you</div></div><a className="button button-outline" href="#contact">Work with us <ArrowUpRight size={17}/></a></div>
        </section>

        <section className="contact-section section-pad" id="contact">
          <div className="section-label">GET IN TOUCH <span>04</span></div>
          <div className="contact-grid"><div><h2>Have a project<br/>in <em>mind?</em></h2><p>Tell us a little about what you need. Let's make it happen.</p><div className="contact-details"><a href="mailto:hello@wazuristudios.com"><Mail size={17}/> hello@wazuristudios.com</a><a href="tel:+254707739621"><Phone size={17}/> +254 707 739 621</a><span><MapPin size={17}/> Kenya</span></div></div>
            <form className="contact-form" onSubmit={submit}><label>Your name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Name"/></label><label>Email address<input type="email" required value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="you@example.com"/></label><label>What do you need?<select value={form.service} onChange={e=>setForm({...form,service:e.target.value})}>{services.map(s=><option key={s.number}>{s.title}</option>)}</select></label><label>Tell us about your project<textarea required rows="3" value={form.message} onChange={e=>setForm({...form,message:e.target.value})} placeholder="A few details about your project..."/></label><button className="button button-light" type="submit">Send enquiry <ArrowUpRight size={17}/></button>{sent && <p className="success-message">Thank you. Your enquiry has been prepared. Please email or WhatsApp us to complete delivery.</p>}</form>
          </div>
        </section>
      </main>

      <footer className="footer"><a className="brand" href="#home"><span className="brand-mark">W</span><span><b>WAZURI</b><small>STUDIOS</small></span></a><p>Creative thinking. Practical solutions.</p><div className="socials"><a href="#contact" aria-label="Instagram"><Instagram/></a><a href="#contact" aria-label="Facebook"><Facebook/></a><a href="#contact" aria-label="YouTube"><Youtube/></a></div><small>© {new Date().getFullYear()} Wazuri Studios. All rights reserved.</small></footer>
      <button className="admin-trigger" onClick={()=>setAdminOpen(true)} title="Admin access"><Settings size={15}/></button>
      {adminOpen && <div className="modal-backdrop" onClick={()=>setAdminOpen(false)}><div className="admin-modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setAdminOpen(false)}><X/></button><div className="admin-kicker"><LayoutDashboard size={17}/> STUDIO ADMIN</div><h2>Content <em>settings.</em></h2><p className="admin-description">A simple local preview panel for editing the homepage text. Connect authentication and a database before using this as a live admin system.</p><label>Hero headline<input value={content.headline} onChange={e=>setContent({...content,headline:e.target.value})}/></label><label>Hero introduction<textarea rows="3" value={content.intro} onChange={e=>setContent({...content,intro:e.target.value})}/></label><button className="button button-light" onClick={()=>setAdminOpen(false)}>Save changes <CheckCircle2 size={16}/></button><p className="admin-hint">Changes apply in this browser session only.</p></div></div>}
    </div>
  )
}

export default App
