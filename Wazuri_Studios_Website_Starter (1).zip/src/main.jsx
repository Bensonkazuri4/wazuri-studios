import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

const liveUrl = import.meta.env.VITE_LIVE_STREAM_URL || '';
const whatsappNumber = '254707739621';

const services = [
  { n: '01', icon: '✳', title: 'Advertising & Brand Promotion', desc: 'Creative campaigns that put your brand in front of the right audience and make your message memorable.' },
  { n: '02', icon: '▣', title: 'TV Setup & Configuration', desc: 'Professional television installation, channel configuration, signal setup and broadcast support.' },
  { n: '03', icon: '⌘', title: 'Server Setup & Configuration', desc: 'Reliable server installation, configuration, network sharing and business IT infrastructure.' },
  { n: '04', icon: '◎', title: 'Social Media Management', desc: 'Consistent content, page management and strategic digital presence that keeps your audience engaged.' },
  { n: '05', icon: '↗', title: 'Account Creation & Growth', desc: 'Professional social media account setup, optimisation and practical growth strategies.' },
  { n: '06', icon: '⌘', title: 'Website Design & Development', desc: 'Modern, responsive websites designed to present your business clearly and convert visitors into customers.' },
  { n: '07', icon: '▤', title: 'Android Application Development', desc: 'Useful, user-friendly Android applications built around your business needs.' },
  { n: '08', icon: '◉', title: 'Digital Marketing & Branding', desc: 'Build a recognisable online identity through thoughtful design, content and digital strategy.' },
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [playing, setPlaying] = useState(false);
  const closeMenu = () => setMenuOpen(false);
  const message = encodeURIComponent('Hello Wazuri Studios, I would like to enquire about your services.');
  const wa = `https://wa.me/${whatsappNumber}?text=${message}`;

  return <div className="site-shell">
    <div className="topline"><span>CREATIVE MEDIA</span><i /> <span>TECHNOLOGY</span><i /> <span>DIGITAL SOLUTIONS</span><div className="top-right">Kenya · Available for projects</div></div>
    <header className="header">
      <a className="brand" href="#home" onClick={closeMenu}><span className="brand-mark">W<span>.</span></span><span className="brand-name">WAZURI <b>STUDIOS</b><small>CREATIVE. CONNECTED. PROFESSIONAL.</small></span></a>
      <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">{menuOpen ? '✕' : '☰'}</button>
      <nav className={menuOpen ? 'nav open' : 'nav'}>
        <a href="#home" onClick={closeMenu}>Home</a><a href="#services" onClick={closeMenu}>Services</a><a href="#live" onClick={closeMenu}>Live TV</a><a href="#about" onClick={closeMenu}>About</a><a href="#contact" onClick={closeMenu}>Contact</a>
        <a className="nav-cta" href={wa} target="_blank" rel="noreferrer">Let’s talk <span>↗</span></a>
      </nav>
    </header>

    <main>
      <section className="hero" id="home">
        <div className="hero-glow" />
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-line" /> YOUR IDEAS. OUR EXPERTISE.</div>
          <h1>We make your<br/><em>vision</em> work.</h1>
          <p className="hero-lead">Creative media, smart technology and digital solutions that help your brand connect, grow and stand out.</p>
          <div className="hero-actions"><a className="button button-gold" href="#services">Explore our services <span>↗</span></a><a className="text-link" href="#about">Discover Wazuri <span>→</span></a></div>
          <div className="hero-note"><span className="note-dot" /> BUILT AROUND YOUR AMBITION</div>
        </div>
        <div className="hero-art" aria-label="Abstract creative studio artwork">
          <div className="art-orbit orbit-one" /><div className="art-orbit orbit-two" /><div className="art-core"><span>W.</span></div>
          <div className="art-label label-top">IDEAS INTO IMPACT</div><div className="art-label label-bottom">MEDIA / TECH / DIGITAL</div>
          <div className="art-cross cross-one">+</div><div className="art-cross cross-two">+</div>
        </div>
        <div className="hero-bottom"><span>01 / 04</span><span className="hero-bottom-line" /><span>SCROLL TO EXPLORE ↓</span><span className="hero-bottom-right">WAZURI STUDIOS © 2026</span></div>
      </section>

      <section className="intro-strip">
        <p>One creative partner.<br/><strong>Many ways to move forward.</strong></p>
        <div className="strip-copy">From the first idea to the final delivery, we bring creativity and technical know-how together to help you do more.</div>
        <a href="#contact" className="round-arrow" aria-label="Contact us">↗</a>
      </section>

      <section className="section services-section" id="services">
        <div className="section-head"><div><div className="eyebrow"><span className="eyebrow-line" /> WHAT WE DO</div><h2>Solutions that<br/><em>move you forward.</em></h2></div><p>Practical expertise meets thoughtful creativity. Explore services designed to help your business communicate better, operate smarter and grow online.</p></div>
        <div className="services-grid">{services.map(s => <article className="service-card" key={s.n}><div className="service-top"><span>{s.n}</span><span className="service-icon">{s.icon}</span></div><h3>{s.title}</h3><p>{s.desc}</p><a href={wa} target="_blank" rel="noreferrer" aria-label={`Enquire about ${s.title}`} className="card-arrow">↗</a></article>)}</div>
      </section>

      <section className="live-section" id="live">
        <div className="live-copy"><div className="eyebrow"><span className="eyebrow-line" /> WATCH WAZURI</div><h2>Stories worth<br/><em>tuning in for.</em></h2><p>Watch our live programming directly from the Wazuri Studios website. Settle in and stay connected wherever you are.</p><div className="live-status"><span className="pulse" /> LIVE BROADCAST</div></div>
        <div className="player-wrap"><div className="player-top"><span><i className="live-dot" /> WAZURI STUDIOS LIVE</span><span>ONLINE BROADCAST</span></div><div className="player">
          {liveUrl ? <iframe src={liveUrl} title="Wazuri Studios live stream" allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen /> : <div className="player-placeholder"><div className="play-symbol">▶</div><strong>Your live stream will appear here</strong><span>Add your streaming link to the project settings to go live.</span></div>}
        </div><div className="player-bottom"><span>LIVE STREAM PLAYER</span><span>FULL SCREEN AVAILABLE ↗</span></div></div>
      </section>

      <section className="about-section section" id="about">
        <div className="about-visual"><div className="about-frame"><span className="frame-word">WAZURI</span><span className="frame-sub">CREATIVE STUDIO / KENYA</span><div className="frame-circle">W.</div></div><span className="visual-caption">GOOD IDEAS DESERVE GREAT EXECUTION.</span></div>
        <div className="about-copy"><div className="eyebrow"><span className="eyebrow-line" /> A LITTLE ABOUT US</div><h2>We turn good ideas<br/>into <em>real impact.</em></h2><p>Wazuri Studios is a creative and technology-driven studio helping individuals, businesses and organisations bring their ideas to life. We combine media, technology and digital expertise to deliver solutions that are practical, polished and purposeful.</p><p>Whether you are building a brand, setting up your broadcast environment or taking your business online, we are ready to help you make the next move.</p><a className="text-link gold-link" href="#contact">Get to know us <span>→</span></a></div>
      </section>

      <section className="cta-band"><div><div className="eyebrow"><span className="eyebrow-line" /> HAVE A PROJECT IN MIND?</div><h2>Let’s make something<br/><em>worth remembering.</em></h2></div><a className="button button-dark" href={wa} target="_blank" rel="noreferrer">Start a conversation <span>↗</span></a></section>

      <section className="contact-section section" id="contact"><div className="contact-heading"><div className="eyebrow"><span className="eyebrow-line" /> GET IN TOUCH</div><h2>Your next move<br/>starts <em>here.</em></h2><p>Tell us what you are working on. We would love to hear from you.</p></div><div className="contact-details"><a href={wa} target="_blank" rel="noreferrer"><span>WHATSAPP / PHONE</span><strong>+254 707 739 621</strong><b>↗</b></a><a href="mailto:hello@wazuristudios.com"><span>EMAIL</span><strong>hello@wazuristudios.com</strong><b>↗</b></a><div><span>LOCATION</span><strong>Kenya</strong></div></div></section>
    </main>
    <footer className="footer"><a className="brand footer-brand" href="#home"><span className="brand-mark">W<span>.</span></span><span className="brand-name">WAZURI <b>STUDIOS</b><small>CREATIVE. CONNECTED. PROFESSIONAL.</small></span></a><span className="footer-tag">CREATIVE THINKING. PRACTICAL SOLUTIONS.</span><span className="copyright">© 2026 Wazuri Studios. All rights reserved.</span><a href="#home" className="back-top">BACK TO TOP ↑</a></footer>
  </div>;
}

createRoot(document.getElementById('root')).render(<App />);